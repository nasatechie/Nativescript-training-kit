// angular
import { Injectable } from '@angular/core';

@Injectable()
export class RecorderService {

  public record(): void { }
  public stop(): void { }
  
}