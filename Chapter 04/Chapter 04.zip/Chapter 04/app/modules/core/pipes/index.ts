import { OrderByPipe } from './order-by.pipe';

export const PIPES: any[] = [
  OrderByPipe
];